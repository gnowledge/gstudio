#include "storage.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

extern int errno ;

int check(plist){

}

plist Initialize(size_t initialize){
	plist l;
	l->array = (int *)malloc(sizeof(int)*initialize);
	l->count = 0;
	l->head = 0;
	l->tail = 0;
	l->size = initialize;
	return l;
}

plist Resize(plist l, size_t newSize){
	l->array = (int *)realloc(l->array, sizeof(int)*newSize);
	l->size = initialize;
	return l;
}

int ReadAtHead(plist l){
	int errnum;
	if(l->count == 0){
		errnum = errno;
		perror("Error printed by perror");	
	}
	if(l->array == NULL){
		errnum = errno;
		perror("Error printed by perror");
	}

	return l->array[l->head];
}

int RemoveAtHead(plist l){
	int temp = l->head;
	l->count-=1;
	if(check(plist))
		l->head += 1;
	return l->array[temp];
}

int ReadAtTail(plist l){
	int errnum;
	if(l->count == 0){
		errnum = errno;
		perror("Error printed by perror");	
	}
	if(l->array == NULL){
		errnum = errno;
		perror("Error printed by perror");
	}

	return l->array[l->tail];
}

int RemoveAtTail(plist l){
	int temp = l->tail;
	l->count-=1;
	if(check(plist))
		l->head -= 1;
	return l->array[temp];
}

plist WriteAtHead(plist l, int i){
	

}

plist AppendAtHead(plist l, int i){

}

plist WriteAtTail(plist l, int i){

}

plist AppendAtTail(plist l, int i){

}