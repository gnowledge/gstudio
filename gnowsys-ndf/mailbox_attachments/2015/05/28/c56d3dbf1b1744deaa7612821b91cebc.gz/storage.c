#include "storage.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

extern int errno ;

int check(plist l){
	// To check the logical constraint Head<=Tail in the position
	if(l->head <= l->tail)	return 1;
	else 					return 0;
}

plist Initialize(size_t initialize){
	//To initialize the list and the array within it with the given parameter.
	
	plist l;
	l->array = (int *)malloc(sizeof(int)*initialize);
	
	int errnum;
	if(l->array == NULL) {
				errnum = errno;
				perror("THE LIST COULD NOT BE INITIALIZED\n");
			}
	
	l->count = 0;
	l->head = 0;
	l->tail = 0;
	l->size = initialize;
	
	return l;
}

plist Resize(plist l, size_t newSize){
	// To provide the list with a new array size.
	
	l->array = (int *)realloc(l->array, sizeof(int)*newSize);
	
	int errnum;
	if(l->array == NULL) {
				errnum = errno;
				perror("The array is not initialized\n");
			}	
	
	
	l->size = newSize;
	return l;
}

int ReadAtHead(plist l){
	//To read Head from the list.

	int errnum;
	if(l->count == 0){
		errnum = errno;
		perror("List is empty\n");	
	}
	if(l->array == NULL){
		errnum = errno;
		perror("The array is not initialized\n");
	}

	return l->array[l->head];
}

int RemoveAtHead(plist l){
	//TO remove from the Head	
	
	int temp = l->head;
	int errnum;
	//To check the logical constraint	
	if(check(l)){ 
	
		//To check whether we are at the first element or not.
		if((l->head != 0 && l->count!=0) && (l->head+1 == l->size)){ 
			l->count-=1;
			l->head += 1;
		}
		else{
			errnum = errno;
			perror("OUT OF BOUNDS ERROR\n");
		}
	}
		
	return l->array[temp];
}


//To read at the tail.
int ReadAtTail(plist l){	

	int errnum;
	if(l->count == 0){
		errnum = errno;
		perror("The list is empty.");	
	}
	if(l->array == NULL){
		errnum = errno;
		perror("The array in the list is not initialzed.");
	}

	return l->array[l->tail];
}



//To remove from the Tail
int RemoveAtTail(plist l){
	int temp = l->tail;
	int errnum;
	//To check the logical constraint	
	if(check(l)){ 
	
		//To check whether we are at the first element or not.
		if((l->tail != 0 && l->count!=0)){ 
			l->count-=1;
			l->tail -= 1;
		}
		else{
			errnum = errno;
			perror("OUT OF BOUNDS ERROR\n");
		}
	}
		
	return l->array[temp];
}





//To write at the Head at the List
plist WriteAtHead(plist l, int i){
	
	int errnum;
	if(l->count!=0)
		l->array[l->head] = i;
	else{
		errnum = errno;
		perror("THE LIST IS EMPTY\n");
	}
	
	return l;

}

//To append at the Head
plist AppendAtHead(plist l, int i){

	int errnum;
	l->head -=1;
	if(check(l)){
		if(l->head != 0){
			l->array[l->head] = i;	
			l->count += 1;	
		}
		else {
			l->head+=1;
			errnum = errno;
			perror("THE LIST IS EMPTY\n");
		}
		
	}
	else{
		errnum = errno;
		perror("THE LOGICAL CONSTRAINT NOT SATISFIED\n");
	}
	
	return l;

}

//To write at the Tail in the List
plist WriteAtTail(plist l, int i){

	int errnum;
	if(l->count!=0)
		l->array[l->tail] = i;
	else{
		errnum = errno;
		perror("THE LIST IS EMPTY\n");
	}
	
	return l;
}

plist AppendAtTail(plist l, int i){

	int errnum;
	l->tail +=1;
	if(check(l)){
		if(l->tail != l->size){
			l->array[l->tail] = i;	
			l->count += 1;	
		}
		else {
			l->tail-=1;
			errnum = errno;
			perror("THE LIST IS EMPTY\n");
		}/*
		l = Resize(l, l->size + 1);
		l->array[l->tail] = i;	
		l->count += 1;*/
	}
	else{
		errnum = errno;
		perror("THE LOGICAL CONSTRAINT NOT SATISFIED\n");
	}
	
	return l;
	
	
}
