typedef struct _list {
	int *array, head, tail;
	size_t size, count;
} list;
typedef list *plist;

int check(plist);

plist Initialize(size_t initialize);

plist Resize(plist l, size_t newSize);

int ReadAtHead(plist l);

int RemoveAtHead(plist l);

int ReadAtTail(plist l);

int RemoveAtTail(plist l);

plist WriteAtHead(plist l, int i);

plist AppendAtHead(plist l, int i);

plist WriteAtTail(plist l, int i);

plist AppendAtTail(plist l, int i);
